# =========================================
# Makers! Implement your own actions here.
# =========================================
from gpiozero import Servo
from time import sleep

class ServoMove(object):
	def __init__(self):
		self.servo = Servo(26)
		#self.value = value

	def run(self, voice_command):
		if 'maximum' in voice_command:
			self.servo.max()
		elif 'minimum' in voice_command:
			self.servo.min()
		else:
			self.servo.mid()

# =========================================
# Makers! Add your own voice commands here.
# =========================================

actor.add_keyword('change', ServoMove())

return actor